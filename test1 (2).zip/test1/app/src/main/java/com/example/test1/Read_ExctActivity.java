package com.example.test1;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.Util.ContentUriUtil;
import com.example.Util.CopyElfs;
import com.youngfeng.snake.annotations.EnableDragToClose;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

@EnableDragToClose()
public class Read_ExctActivity extends AppCompatActivity {

    //导入操作
    private CopyElfs ce;
    private static final String TAG = "RootCmd";
    // 可执行文件mmc的路径
    private  String mmcpath;
    static final int SUCCESS = 1;
    private static boolean mHaveRoot = false;
    private Process p;
    //文件操作
    private TextView chip_filePah;
    private Button chip_btnSelect;
    //
    private Button mBtnEnter;
    private Button  mBtnClear;
    private TextView tv;
    //导入操作
    // UI线程消息队列
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {//此方法在ui线程运行
            switch (msg.what) {
                case SUCCESS:
                    super.handleMessage(msg);
                    Bundle tBundle = msg.getData();
                    String tCmd = tBundle.getString("OUT");
                    tv.append(tCmd);
                    break;
                default:
                    break;
            }
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);

        mBtnClear = (Button)findViewById(R.id. mBtnClear);
        mBtnEnter = (Button)findViewById(R.id.btn_Enter);
        tv = (TextView)findViewById(R.id.sample_text);
        tv.setMovementMethod(ScrollingMovementMethod.getInstance());
        //
        ce = new CopyElfs(getBaseContext());
        ce.copyAll2Data();
        try {
            p = Runtime.getRuntime().exec("su");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //可执行文件路径
        mmcpath = ce.getExecutableFilePath()+"/mmc read";

        chip_filePah = findViewById(R.id.chip_file_path);
        chip_btnSelect = findViewById(R.id.chip_open_file);


        mBtnEnter.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String seleted_cmd = mmcpath +  chip_filePah.getText().toString();
                Log.i("cmd",seleted_cmd);
                if (seleted_cmd != "") {
                    try {
                        callElf(seleted_cmd);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        chip_btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSystemFile(1);
            }
        });

         mBtnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 tv.setText("");
            }
        });
    }


    public void openSystemFile(int status) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        // 所有类型
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            if(status == 1){
                startActivityForResult(Intent.createChooser(intent, "请选择文件"), status);
            }
            else if (status == 2){
                startActivityForResult(Intent.createChooser(intent, "请选择文件"), status);
            }

        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
            Toast.makeText( Read_ExctActivity.this, "请安装文件管理器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            //Get the Uri of the selected file
            Uri uri = data.getData();
            if (null != uri) {
                String path = ContentUriUtil.getPath(this, uri);
                updatechip_filePah(path);
            }
        }
    }

    private void updatechip_filePah(final String path) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                chip_filePah.setText(path);
            }
        });
    }


    public void callElf(String cmd) throws InterruptedException {
        String tmpText;
        DataOutputStream dos = null;
        BufferedReader br = null;
        BufferedReader err = null;
        try {
            Log.i("DOS", "start su");
            //Process p = Runtime.getRuntime().exec("su");
            Log.i("DOS", "end su");
            dos = new DataOutputStream(p.getOutputStream());// 写入流
            br = new BufferedReader(new InputStreamReader(p.getInputStream()));// 输出缓存
            err = new BufferedReader(new InputStreamReader(p.getErrorStream()));// 错误流缓存

            dos.writeBytes(cmd + "\n");
            dos.flush();
            dos.writeBytes("exit\n");
            dos.flush();

            // 先读取错误流
            while ((tmpText = err.readLine()) != null || (tmpText = br.readLine()) != null) {
                tmpText += "\n";
                myCallbackFunc(tmpText);
            }

            // 等待shell子进程执行完成,返回0表示正常结束
            p.waitFor();
        }catch (IOException e){
            e.printStackTrace();
        }
        finally {
            // 关闭流
            if (dos != null) {
                try {
                    dos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        //return execResult;
    }
    // 向UI线程发送Message
    public void myCallbackFunc(String nMsg) {
        Message tMsg = new Message();
        Bundle tBundle = new Bundle();
        tMsg.what = SUCCESS;
        tBundle.putString("OUT", nMsg);
        tMsg.setData(tBundle);
        handler.sendMessage(tMsg);
    }

    // 执行命令并且输出结果
    public void execRootCmd(String cmd) throws IOException {
        DataOutputStream dos = null;
        InputStream dis = null;
        BufferedReader bin = null;
        BufferedReader errorStreamReader = null;
        try {
            Process p = Runtime.getRuntime().exec("su");// 经过Root处理的android系统即有su命令
            dos = new DataOutputStream(p.getOutputStream());

            errorStreamReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            bin = new BufferedReader(new InputStreamReader(p.getInputStream()));

            Log.i("DOS", "dos.writeBytes：" + cmd);
            dos.writeBytes(cmd + "\n");
            Log.i("DOS", "after dos.writeBytes：" + cmd);
            dos.flush();
            dos.writeBytes("exit\n");
            dos.flush();
            String line = null;

            while ((line = bin.readLine()) != null) {
                line += "\n";
                Log.i("printf",  line);
                // 将读取的输出发送到消息队列
                myCallbackFunc(line);
            }
            p.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (dos != null) {
                try {
                    dos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (bin.readLine() != null) {
                try {
                    dis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
