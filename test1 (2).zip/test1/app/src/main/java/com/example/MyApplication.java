package com.example;

import android.app.Application;

import com.youngfeng.snake.Snake;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Snake.init(this);
    }


}