package com.example.test1;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    private TextView ffu;
    private TextView help;
    private TextView read;

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //其他组件
        ffu = (TextView) findViewById(R.id.ffu);
        help = (TextView)findViewById(R.id.help);
        read = (TextView)findViewById(R.id.read);

        //多个按钮监听跳转
        View.OnClickListener mylistener = new View.OnClickListener() {
            Intent intent=null;
            @Override
            public void onClick(View view) {

                switch (view.getId()){
                    case R.id.ffu:
                        intent=new Intent(MainActivity.this,FFUActivity.class);
                        break;
                    case R.id.help:
                        intent=new Intent(MainActivity.this,HelpActivity.class);
                        break;
                    case R.id.read:
                        intent=new Intent(MainActivity.this,Read_ExctActivity.class);
                        break;
                    default:
                        break;
                }
                startActivity(intent);
            }
        };


        //更新固件进行跳转
        ffu.setOnClickListener(mylistener);
        //查看手册进行跳转
        help.setOnClickListener(mylistener);
        read.setOnClickListener(mylistener);
    }
}
